#include <errno.h>
#include <signal.h>
#include <stdarg.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#define INTERVAL 3

#define AUTO_THRESHOLD   50000
#define MANUAL_THRESHOLD 45000

#define MANUAL_DUTY_CYCLE 85

#define PWM_INPUT  "/sys/class/hwmon/hwmon3/pwm1"
#define PWM_ENABLE "/sys/class/hwmon/hwmon3/pwm1_enable"
#define TEMP_INPUT "/sys/class/hwmon/hwmon3/temp1_input"

enum pwm_mode {
  PWM_MAX    = 0,
  PWM_MANUAL = 1,
  PWM_AUTO   = 2
};

static void error(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  fputs("leque: error: ", stderr);
  vfprintf(stderr, fmt, ap);
  fputc('\n', stderr);
  va_end(ap);
}

static void set_pwm_mode(enum pwm_mode);

static void fatal(const char *fmt, ...) {
  va_list ap;

  va_start(ap, fmt);
  fputs("leque: error: ", stderr);
  vfprintf(stderr, fmt, ap);
  fputc('\n', stderr);
  va_end(ap);

  set_pwm_mode(PWM_AUTO);
  exit(EXIT_FAILURE);
}

static void sig_handler(int sig) {
  if (sig == SIGINT || sig == SIGHUP || sig == SIGTERM) {
    set_pwm_mode(PWM_AUTO);
    exit(EXIT_SUCCESS);
  }
}

static void set_pwm(uint8_t duty_cycle) {
  static FILE *f = NULL;

  if (f == NULL) {
    if ((f = fopen(PWM_INPUT, "w")) == NULL) {
      fatal("failed to open '%s' -- %s", PWM_INPUT, strerror(errno));
    }
  } else if (fseek(f, 0, SEEK_SET) == -1) {
    fatal("failed to seek to beginning of '%s' -- %s", PWM_INPUT, strerror(errno));
  }

  if (fprintf(f, "%u\n", duty_cycle) == -1) {
    fatal("failed to set pwm duty cycle to %u -- %s", duty_cycle, strerror(errno));
  }
  fflush(f);
}

static void set_pwm_mode(enum pwm_mode mode) {
  static FILE *f = NULL;

  // Sometimes, during boot, the file doesn't yet exist. I'm not sure how
  // to properly handle this. This seems to work fine.
  if (f == NULL) {
    for (int i = 0; i < 5; i++) {
      if ((f = fopen(PWM_ENABLE, "w")) == NULL) {
        sleep(1);
      } else {
        break;
      }
    }
  }
  if (f == NULL) {
    error("failed to open '%s' -- %s", PWM_ENABLE, strerror(errno));
    exit(EXIT_FAILURE);
  } else if (fseek(f, 0, SEEK_SET) == -1) {
    error("failed to seek to beginning of '%s' -- %s", PWM_ENABLE, strerror(errno));
  }

  if (fprintf(f, "%d\n", mode) == -1) {
    error("failed to set pwm mode to %d -- %s", mode, strerror(errno));
  }
  fflush(f);
}

static int read_temperature(void) {
  static FILE *f = NULL;
  int temperature = 100000;

  if (f == NULL) {
    if ((f = fopen(TEMP_INPUT, "r")) == NULL) {
      fatal("failed to open '%s' -- %s", TEMP_INPUT, strerror(errno));
    }
  } else if (fseek(f, 0, SEEK_SET) == -1) {
    fatal("failed to seek to beginning of '%s' -- %s", TEMP_INPUT, strerror(errno));
  }

  fscanf(f, "%d\n", &temperature);
  return temperature;
}

int main(int argc, char **argv) {
  if (argc != 1) {
    fprintf(stderr, "usage: %s\n", argv[0]);
    return EXIT_FAILURE;
  }

  errno = 0;
  signal(SIGINT, sig_handler);
  signal(SIGHUP, sig_handler);
  signal(SIGTERM, sig_handler);
  if (errno > 0) {
    error("failed to set signal handler -- %s", strerror(errno));
    exit(EXIT_FAILURE);
  }

  // For safety, start on auto mode.
  set_pwm_mode(PWM_AUTO);
  int last_temperature = AUTO_THRESHOLD;

  for (;;) {
    int temperature = read_temperature();

    if (last_temperature < AUTO_THRESHOLD && temperature >= AUTO_THRESHOLD) {
      set_pwm_mode(PWM_AUTO);
    } else if (last_temperature > MANUAL_THRESHOLD && temperature <= MANUAL_THRESHOLD) {
      set_pwm_mode(PWM_MANUAL);
      set_pwm(MANUAL_DUTY_CYCLE);
    }
    last_temperature = temperature;
    sleep(INTERVAL);
  }
  return EXIT_SUCCESS;
}
